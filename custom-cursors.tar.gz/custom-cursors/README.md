run automated.sh, enter a hex-color code to be used (be sure to include the #) and press enter.
within seconds you will have a custom cursor theme created and isntalled.

if you wish to do more serious edits, copy the files in the /default directory to a new directory called /src
and edit the .svg files, then run generate-only.sh
